/* graph.js */

function initKnowledgeGraph() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  const canvases = document.querySelectorAll('.knowledge-graph-canvas');
  if (!canvases.length) return;

  canvases.forEach(canvas => {
    const ctx = canvas.getContext('2d');
    let width, height;
    let nodes = [];
    let signals = [];
    let animationFrame;
    let frame = 0;
    let mouseX = -1000;
    let mouseY = -1000;

    const colors = {
      document: '#F59E0B',
      person: '#4F46E5',
      data: '#818CF8',
      insight: '#10B981',
      process: 'rgba(255,255,255,0.6)'
    };
    const types = ['document', 'person', 'data', 'insight', 'process'];

    function resize() {
      const rect = canvas.parentElement.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      const dpr = window.devicePixelRatio || 1;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    function createNodes() {
      nodes = [];
      const numNodes = width > 1000 ? 90 : (width > 640 ? 62 : 42);
      for (let i = 0; i < numNodes; i++) {
        const type = types[i % types.length];
        nodes.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * 0.25,
          vy: (Math.random() - 0.5) * 0.25,
          type: type,
          size: 2.5 + Math.random() * 4.5,
          pulse: Math.random() * Math.PI * 2,
          pulseSpeed: 0.008 + Math.random() * 0.01,
          color: colors[type],
          opacity: 0.5 + Math.random() * 0.5
        });
      }
    }

    canvas.addEventListener('mousemove', e => {
      const rect = canvas.getBoundingClientRect();
      mouseX = e.clientX - rect.left;
      mouseY = e.clientY - rect.top;
    });
    canvas.addEventListener('mouseleave', () => {
      mouseX = -1000;
      mouseY = -1000;
    });

    function loop() {
      frame++;
      ctx.clearRect(0, 0, width, height);
      
      // Update nodes
      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i];
        
        // Bounce
        if (node.x < node.size || node.x > width - node.size) node.vx *= -0.95;
        if (node.y < node.size || node.y > height - node.size) node.vy *= -0.95;
        
        // Attraction
        const dx = mouseX - node.x;
        const dy = mouseY - node.y;
        const distToMouse = Math.sqrt(dx * dx + dy * dy);
        
        if (!isTouch && distToMouse > 0 && distToMouse < 200) {
          const attraction = Math.pow(1 - distToMouse / 200, 1.5) * 0.6;
          node.vx += (dx / distToMouse) * attraction * 0.04;
          node.vy += (dy / distToMouse) * attraction * 0.04;
        }

        if (frame % 180 === 0) {
          node.vx += (Math.random() - 0.5) * 0.02;
          node.vy += (Math.random() - 0.5) * 0.02;
        }

        // Speed cap
        const speed = Math.sqrt(node.vx * node.vx + node.vy * node.vy);
        if (speed > 0.25) {
          node.vx *= 0.98;
          node.vy *= 0.98;
        }

        node.x += node.vx;
        node.y += node.vy;
        node.pulse += node.pulseSpeed;
      }

      // Draw edges
      ctx.lineWidth = 0.6;
      const visibleEdges = [];
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          // Manhattan optimization
          if (Math.abs(dx) > 130 || Math.abs(dy) > 130) continue;
          
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 130) {
            const op = Math.pow(1 - dist / 130, 1.8) * 0.22;
            ctx.strokeStyle = `rgba(255, 255, 255, ${op})`;
            ctx.beginPath();
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.stroke();
            if (op > 0.08) visibleEdges.push([nodes[i], nodes[j]]);
          }
        }
      }

      if (frame % 108 === 0 && visibleEdges.length && signals.length < 8) {
        const edge = visibleEdges[Math.floor(Math.random() * visibleEdges.length)];
        signals.push({ from: edge[0], to: edge[1], t: 0, color: edge[0].color });
      }

      signals = signals.filter(signal => signal.t < 1);
      signals.forEach(signal => {
        signal.t += 0.012;
        const eased = signal.t * signal.t * (3 - 2 * signal.t);
        const x = signal.from.x + (signal.to.x - signal.from.x) * eased;
        const y = signal.from.y + (signal.to.y - signal.from.y) * eased;
        const alpha = signal.t < 0.1 ? signal.t / 0.1 : signal.t > 0.9 ? (1 - signal.t) / 0.1 : 1;
        ctx.beginPath();
        ctx.arc(x, y, 3, 0, Math.PI * 2);
        ctx.fillStyle = signal.color;
        ctx.globalAlpha = Math.max(0, alpha);
        ctx.fill();
        ctx.globalAlpha = 1;
      });

      nodes.forEach(node => {
        const pSize = node.size + Math.sin(node.pulse) * 1.2;
        ctx.beginPath();
        ctx.arc(node.x, node.y, pSize * 4, 0, Math.PI * 2);
        ctx.fillStyle = node.color;
        ctx.globalAlpha = 0.06;
        ctx.fill();

        ctx.beginPath();
        if (node.type === 'document') {
          ctx.roundRect(node.x - pSize, node.y - pSize, pSize * 2, pSize * 2, 2);
        } else {
          ctx.arc(node.x, node.y, pSize, 0, Math.PI * 2);
        }
        ctx.fillStyle = node.color;
        ctx.globalAlpha = 0.65 + node.opacity * 0.3;
        ctx.fill();
        ctx.globalAlpha = 1;
      });

      animationFrame = requestAnimationFrame(loop);
    }

    resize();
    createNodes();
    loop();

    window.addEventListener('resize', () => {
      cancelAnimationFrame(animationFrame);
      clearTimeout(canvas.resizeTimeout);
      canvas.resizeTimeout = setTimeout(() => {
        resize();
        createNodes();
        loop();
      }, 200);
    });
  });
}
