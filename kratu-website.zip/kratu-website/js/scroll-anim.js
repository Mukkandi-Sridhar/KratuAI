/* scroll-anim.js */

function sectionWordReveal(selector, trigger) {
  if (!document.querySelector(selector)) return;
  const split = new SplitType(selector, { types: 'lines,words' });
  
  return gsap.from(split.words, {
    scrollTrigger: {
      trigger: trigger || selector,
      start: 'top 78%',
      once: true
    },
    y: 50,
    opacity: 0,
    stagger: 0.055,
    duration: 0.7,
    ease: 'power3.out'
  });
}

function applyPattern(pattern, targets, el) {
  const st = { trigger: el, start: 'top 85%', once: true };
  
  switch(pattern) {
    case 'scale':
      gsap.from(targets, { scrollTrigger: st, scale: 0.88, opacity: 0, duration: 0.7, stagger: 0.08, ease: 'back.out(1.2)' });
      break;
    case 'wipe':
      gsap.from(targets, { scrollTrigger: st, scaleX: 0, transformOrigin: 'left center', duration: 0.9, ease: 'power2.inOut' });
      break;
    case 'split':
      if (targets.length >= 2) {
        gsap.from(targets[0], { scrollTrigger: st, x: -40, opacity: 0, duration: 0.8, ease: 'power3.out' });
        gsap.from(targets[1], { scrollTrigger: st, x: 40, opacity: 0, duration: 0.8, ease: 'power3.out' });
      }
      break;
    case 'cascade':
      targets.forEach((target, i) => {
        gsap.from(target, { scrollTrigger: st, x: i % 2 === 0 ? -24 : 24, opacity: 0, duration: 0.65, delay: i * 0.09 });
      });
      break;
    case 'rise':
    default:
      gsap.from(targets, { scrollTrigger: st, y: 70, opacity: 0, duration: 0.85, stagger: 0.1, ease: 'power3.out' });
      break;
  }
}

function initScrollAnimations() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  gsap.utils.toArray('[data-anim]').forEach(el => {
    const pattern = el.dataset.anim || 'rise';
    const children = el.querySelectorAll('[data-anim-child]');
    const targets = children.length ? children : el;
    applyPattern(pattern, targets, el);
  });

  // Top progress bar
  const progressBar = document.querySelector('.scroll-progress-bar');
  if (progressBar) {
    ScrollTrigger.create({
      trigger: document.body,
      start: 'top top',
      end: 'bottom bottom',
      scrub: 0.8,
      onUpdate: (self) => {
        progressBar.style.width = (self.progress * 100) + '%';
      }
    });
  }
}

document.addEventListener('DOMContentLoaded', initScrollAnimations);
