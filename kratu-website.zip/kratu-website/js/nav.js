/* nav.js */

function initNav() {
  const nav = document.querySelector('.nav');
  if (!nav) return;
  
  let navScrolled = false;

  const setFrost = (scroll) => {
    const shouldFrost = scroll > 60;
    const lightNav = document.body.classList.contains('theme-light');
    
    if (shouldFrost !== navScrolled) {
      navScrolled = shouldFrost;
      const styles = {
        backdropFilter: shouldFrost ? 'blur(24px) saturate(180%)' : 'blur(0px)',
        backgroundColor: shouldFrost
          ? (lightNav ? 'rgba(249,247,242,0.88)' : 'rgba(5,5,13,0.82)')
          : (lightNav ? 'rgba(249,247,242,0.88)' : 'rgba(5,5,13,0)'),
        borderBottomColor: shouldFrost
          ? (lightNav ? 'rgba(14,13,28,0.08)' : 'rgba(255,255,255,0.06)')
          : (lightNav ? 'rgba(14,13,28,0.08)' : 'rgba(255,255,255,0)')
      };

      if (typeof gsap !== 'undefined') {
        gsap.to(nav, { ...styles, duration: 0.4, ease: 'power2.out' });
      } else {
        Object.assign(nav.style, styles);
      }
    }
  };

  if (window.lenis && typeof window.lenis.on === 'function') {
    window.lenis.on('scroll', ({ scroll }) => setFrost(scroll));
  } else if (typeof lenis !== 'undefined' && lenis && typeof lenis.on === 'function') {
    lenis.on('scroll', ({ scroll }) => setFrost(scroll));
  } else {
    window.addEventListener('scroll', () => setFrost(window.scrollY), { passive: true });
  }

  const toggle = nav.querySelector('.nav-toggle');
  const menu = nav.querySelector('.mobile-menu');
  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('menu-open');
      toggle.setAttribute('aria-expanded', String(isOpen));
      menu.setAttribute('aria-hidden', String(!isOpen));
      document.documentElement.classList.toggle('lenis-stopped', isOpen);
    });

    menu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        nav.classList.remove('menu-open');
        toggle.setAttribute('aria-expanded', 'false');
        menu.setAttribute('aria-hidden', 'true');
        document.documentElement.classList.remove('lenis-stopped');
      });
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  // Wait a bit to ensure lenis is initialized
  setTimeout(initNav, 100);
});
