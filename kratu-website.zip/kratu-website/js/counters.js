/* counters.js */

function initCounters() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  gsap.utils.toArray('.stat-number').forEach(el => {
    const final = parseFloat(el.dataset.value);
    const suffix = el.dataset.suffix || '';
    const prefix = el.dataset.prefix || '';
    
    ScrollTrigger.create({
      trigger: el,
      start: 'top 85%',
      once: true,
      onEnter: () => {
        gsap.to(el, {
          innerText: final,
          duration: 2.2,
          ease: 'power2.out',
          snap: { innerText: Number.isInteger(final) ? 1 : 0.1 },
          onUpdate: function() {
            const val = parseFloat(this.targets()[0].innerText);
            const display = Number.isInteger(final) 
              ? Math.floor(val).toLocaleString('en-IN')
              : val.toFixed(1);
            el.textContent = prefix + display + suffix;
          },
          onComplete: () => {
            gsap.to(el, {
              scale: 1.06, duration: 0.15, yoyo: true, repeat: 1,
              ease: 'power1.inOut'
            });
          }
        });
      }
    });
  });
}

document.addEventListener('DOMContentLoaded', initCounters);
