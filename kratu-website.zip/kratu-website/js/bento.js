/* bento.js */

function initBentoGlow() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || isTouch) return;

  document.querySelectorAll('.bento-card').forEach(card => {
    card.style.setProperty('--gx', '50%');
    card.style.setProperty('--gy', '50%');
    
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width * 100).toFixed(1);
      const y = ((e.clientY - rect.top) / rect.height * 100).toFixed(1);
      card.style.setProperty('--gx', x + '%');
      card.style.setProperty('--gy', y + '%');
    });
    
    card.addEventListener('mouseenter', () => {
      gsap.to(card, { scale: 1.025, y: -3, duration: 0.25, ease: 'power2.out' });
    });
    
    card.addEventListener('mouseleave', () => {
      gsap.to(card, { scale: 1, y: 0, duration: 0.3, ease: 'power2.out' });
    });
  });
}

document.addEventListener('DOMContentLoaded', initBentoGlow);
