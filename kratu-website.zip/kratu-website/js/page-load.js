/* page-load.js */

function heroWordReveal(selector = '.hero-headline') {
  if (!document.querySelector(selector)) return gsap.timeline();
  const split = new SplitType(selector, { types: 'lines,words' });
  
  return gsap.from(split.words, {
    y: 60,
    opacity: 0,
    rotateX: 12,
    transformOrigin: '0% 50% -50',
    stagger: { each: 0.075, from: 'start' },
    duration: 0.8,
    ease: 'power4.out'
  });
}

function initPageLoad() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.body.style.opacity = 1;
    if(typeof initKnowledgeGraph === 'function') initKnowledgeGraph();
    return;
  }

  const tl = gsap.timeline({
    defaults: { ease: 'power3.out' },
    onStart: () => {
      if(typeof initKnowledgeGraph === 'function') initKnowledgeGraph();
    }
  });

  tl.to('body', { opacity: 1, duration: 0.25, ease: 'none' }, 0)
    .from('.nav', { y: -40, opacity: 0, duration: 0.6 }, 0.15)
    .from('.hero-badge', { scale: 0.75, opacity: 0, duration: 0.5, ease: 'back.out(2)' }, 0.35)
    .add(heroWordReveal(), 0.55)
    .from('.hero-sub', { y: 24, opacity: 0, duration: 0.7 }, 1.1)
    .from('.hero-copy .cta-row .btn', {
      y: 18,
      opacity: 0,
      scale: 0.93,
      stagger: 0.1,
      duration: 0.55,
      clearProps: 'opacity,transform'
    }, 1.35)
    .from('.hero-trust', { opacity: 0, duration: 0.5 }, 1.6)
    .from('.hero-chat', { x: 50, opacity: 0, duration: 0.85, ease: 'power2.out' }, 1.75)
    .from('.stat-card', { y: -30, opacity: 0, stagger: 0.14, duration: 0.65 }, 2.0)
    .from('.scroll-hint', { opacity: 0, y: 10, duration: 0.5 }, 2.5);

  tl.then(() => {
    if(document.querySelector('.hero-headline')) {
      gsap.to('.hero-headline', {
        y: -5, duration: 3.5, ease: 'sine.inOut',
        yoyo: true, repeat: -1
      });
    }
  });
}

document.addEventListener('DOMContentLoaded', initPageLoad);
