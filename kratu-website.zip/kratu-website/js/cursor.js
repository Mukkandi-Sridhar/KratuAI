/* cursor.js */

function initCursorAura() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || isTouch) return;

  const aura = document.createElement('div');
  aura.className = 'cursor-aura';
  document.body.appendChild(aura);

  const xSetter = gsap.quickSetter(aura, 'x', 'px');
  const ySetter = gsap.quickSetter(aura, 'y', 'px');

  window.addEventListener('mousemove', e => {
    xSetter(e.clientX - 300);
    ySetter(e.clientY - 300);
  });
}

document.addEventListener('DOMContentLoaded', initCursorAura);
