/* init.js */

// Global state
let lenis;
let isTouch = false;

function initCore() {
  if ('ontouchstart' in window) {
    isTouch = true;
    document.body.classList.add('is-touch');
  }

  // Set viewport height CSS var to fix mobile 100vh issue
  const setVH = () => {
    document.documentElement.style.setProperty('--vh', window.innerHeight * 0.01 + 'px');
  };
  setVH();
  window.addEventListener('resize', () => {
    clearTimeout(window.vhTimeout);
    window.vhTimeout = setTimeout(setVH, 150);
  });

  // Check reduced motion
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    gsap.defaults({ duration: 0, delay: 0 });
    return;
  }

  // Initialize Lenis
  lenis = new Lenis({
    lerp: 0.072,
    smoothWheel: true,
    wheelMultiplier: 0.85,
    touchMultiplier: 1.4,
    infinite: false
  });
  window.lenis = lenis;

  // Wire Lenis to GSAP ticker
  gsap.ticker.add((time) => {
    lenis.raf(time * 1000);
  });
  gsap.ticker.lagSmoothing(0);
  
  if (typeof ScrollTrigger !== 'undefined') {
    lenis.on('scroll', ScrollTrigger.update);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  if (typeof gsap !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger, TextPlugin);
  }
  initCore();
});
